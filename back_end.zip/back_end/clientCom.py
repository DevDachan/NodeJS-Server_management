import requests
import schedule
import os
import pymysql
import json

global id

# 암호화/복호화 모듈 사용
import base64

from Cryptodome import Random
from Cryptodome.Cipher import AES

from Cryptodome import Random
from Cryptodome.Cipher import AES

BS = 16
pad = lambda s: s + (BS - len(s.encode('utf-8')) % BS) * chr(BS - len(s.encode('utf-8')) % BS)
unpad = lambda s : s[:-ord(s[len(s)-1:])]

key = [0x10, 0x01, 0x15, 0x1B, 0xA1, 0x11, 0x57, 0x72, 0x6C, 0x21, 0x56, 0x57, 0x62, 0x16, 0x05, 0x3D, 0xFF, 0xFE, 0x11, 0x1B, 0x21, 0x31, 0x57, 0x72, 0x6B, 0x21, 0xA6, 0xA7, 0x6E, 0xE6, 0xE5, 0x3F]

class AESCipher:
    def __init__( self, key ):
        self.key = key

    def encrypt( self, raw ):
        raw = pad(raw)
        iv = Random.new().read( AES.block_size )
        cipher = AES.new( self.key, AES.MODE_CBC, iv )
        return base64.b64encode( iv + cipher.encrypt( raw.encode('utf-8') ) )

    def decrypt( self, enc ):
        enc = base64.b64decode(enc)
        iv = enc[:16]
        cipher = AES.new(self.key, AES.MODE_CBC, iv )
        return unpad(cipher.decrypt( enc[16:] ))

with open("db.json",'r') as db:
    db_data = json.load(db)

conn = pymysql.connect(
    host=db_data['info']['host'],
    user=db_data['info']['user'],
    password=db_data['info']['password'],
    db=db_data['info']['db'],
    charset='utf8'
)

url = "http://127.0.0.1:5000"

# cpu load : cpu에 실행중이거나 대기중인 작업의 개수를 평균으로 보여주는 값
# workload : 주어진 기간에 시스템에 의해 실행되어야 할 작업의 할당량
# 명령어 - uptime, top


#info_str = ''
#for i in range(len(line)):
#	info_str += line[i]
#	if i < len(line)-1:
#		info_str += '\n'
#
#print(info_str)

def sending():

    os.system('powertop --html=process.html -time=1')



    f=open("process.html","rt")


    temp = 0

    state_cpu = 'no'
    state_power = 'no'


    cpu_usage = ''
    power_usage = 0

    while True:
        line = f.readline()
        if not line :
            break

        if line.find('<br/><div id="main_menu"> </div>') != -1:
            state_cpu = 'ok'
        elif line.find('<h2 class="content_title"> Overview of Software Power Consumers </h2>') != -1:
            state_power = 'ok';

        if state_cpu == 'ok':
            if line.find('<li class="summary_list">') != -1:
                cpu_temp = line.split('<li class="summary_list"> <b> CPU:  </b>')
                cpu_usage = cpu_temp[1].split('</li><li class="summary_list">')[0]
                cpu_usage = float(cpu_usage.split('%')[0])
                state_cpu = 'no'
            elif line.find('<div class="clear_block" id="summary">') != -1:
                state_cpu = 'no'

        if state_power == "ok" :
            if line.find('<tr class="emph1">') != -1 & line.find('<th class="emph_title"> Usage </th> <th class="emph_title"> Wakeups/s </th> ') == -1 :
                temp =  line.split('<td class="no_wrap">')[-1]
                if temp.find('uW') != -1:
                    power_uw = temp.split('uW')[0]
                    print(float(power_uw),'uW')
                    power_usage += float(power_uw)*0.000001
                elif temp.find('mW') != -1:
                    power_mw = temp.split('mW')[0]
                    print(float(power_mw),'mW')
                    power_usage += float(power_mw)*0.001
                elif temp.find('W') != -1:
                    power_w = temp.split('W')[0]
                    print(float(power_w),'W')
                    power_usage += float(power_w)
            if line.find('</table>') != -1 :
                break
    print('cpu_usage = ', cpu_usage,"%")
    print('power_usage = ', power_usage,"W")
    f.close()

    if(power_usage == 0 )
        print('power usage error')
    elif(cpu_usage == 0 || cpu_usage == '')
        print('cpu usage error')

    uptime = os.popen('uptime').read()
    line = uptime.split(', ')
    # print(line[2][0]) # user number

    top = os.popen('top').read(200)
    # print('user index: ', top.find('idle'))
    line2 = top.split('\n')
    # print(line2)
    cpu = line2[3].split(' ')
    print('cpu_user: ', cpu[2])
    print('cpu_sys: ', cpu[4])

    cpu_user = cpu[2].split(' ')
    cpu_sys = cpu[4].split(' ')
    # print(cpu_user[0].split('%')[0])
    # print(cpu_sys[0].split('%')[0])

    cpuUser_float = float(cpu_user[0].split('%')[0])
    cpuSys_float = float(cpu_sys[0].split('%')[0])

    total_cpu = str(round((cpuUser_float + cpuSys_float), 2)) + '%'

    # print(type(total_cpu))
    print('total_cpu: ', total_cpu)

    date = os.popen('date "+%Y-%m-%d %H:%M:%S"').read().split('\n')[0]

    on_datas = {
		'id' : id,
		'time' : date,
		'state' : 'on',
        'cpu_usage' : total_cpu,
		'user_num' : line[2][0],
        'power_usage' : power_usage
	}

    response = requests.get(url, params=on_datas)

    if response.status_code == 200:
        print(response.url);

schedule.every(8).seconds.do(sending)
# schedule.every(3).minutes.do(sending)

try:
    check = 0; # 0 : id no exist, 1 : id exist

    try: # 파일에 id가 저장되어 있으면
        f = open('save_id.txt', 'rb') # 파일에 있는 id 불러오기
        file_id = f.read()

        id_dec = AESCipher(bytes(key)).decrypt(file_id) # 불러온 id 복호화
        dec_str = id_dec.decode('utf-8') # 바이트 형태를 string으로
        # print(dec_str)

        # if) 불러온 id가 db에 없으면(웹서버에서 delete한 경우)
        # id 다시 입력 받는 곳으로 가기

        cur2 = conn.cursor()
#        sql_select = 'select id from server_list'
#        cur2.execute(sql_select)

        sql_select2 = 'select id from server_list where id = %s'
        result_len = cur2.execute(sql_select2, (dec_str)) # 0: not exist, 1: exist
        # print(result_len)

        if result_len == 1:
            print('id를 자동으로 불러옵니다.')
            print('id : ' + dec_str)
            id = dec_str
            check = 1
        else:
            print('삭제된 클라이언트입니다!')
            raise Exception('삭제된 클라이언트입니다!')
            # flnrph30

        f.close()

#        for row in cur2:
#            print(row[0])
#            print('id', dec_str)
#            if row[0] == dec_str: # db에 입력한 id가 있으면
#                print('id를 자동으로 불러옵니다.')
#                print('id : ' + dec_str)
#                id = dec_str
#
#                f.close()
#                check = 1
#                break
#            else:
#                print('삭제된 클라이언트입니다!')
#                raise Exception('삭제된 클라이언트입니다!')

        # else) 자동으로 불러오기



    except:
        # print('no file')

        id = input("Client id 입력 : ")

        cur = conn.cursor()
        sql_select = 'select id from server_list'
        cur.execute(sql_select)

        for row in cur:
            # print("row: ", row[0])
            if row[0] == id: # db에 입력한 id가 있으면
                check = 1
                break
            else:
                check = 0

    # print("check: ", check);
    if(check == 1):
        print("'" + id + "'", "id로 접속 완료!")

        id_enc = AESCipher(bytes(key)).encrypt(id) # 암호화
        # print(id_enc)

        f = open('save_id.txt', 'wb') # 암호화 한 것 파일에 쓰기
        f.write(id_enc)

        f.close()
        while True:
            schedule.run_pending()
            # time.sleep(1)
    else:
        print("입력한 id는 등록이 되어 있지 않은 id입니다.\nWeb Server에서 등록 후 이용해주세요!")
except KeyboardInterrupt:
    end_time = os.popen('date "+%Y-%m-%d %H:%M:%S"').read().split('\n')[0]
    off_datas = {
        'id' : id,
        'time' : end_time,
        'state' : 'off',
        # 'user_num' : line[2][0],
    }
    response = requests.get(url, params=off_datas)

# 새로 등록하면 접속 완료 됐을 때 새로운 텍스트 파일 만들어 줌
# 만들어진 텍스트 파일에는 id가 암호화되어 저장

# 텍스트 파일 있으면 등록된 id가 있다고 알려주기
# id를 복호화하여 불러와줌
# 불러온 id를 가지고 데이터 전송
