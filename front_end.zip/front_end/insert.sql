use server_management;

DELETE FROM server_list WHERE id IS NOT NULL;
DELETE FROM history WHERE id IS NOT NULL; 
INSERT INTO history VALUE("15","2022-09-23/16:54:05","30%","12");

INSERT INTO history VALUE("13","2022-09-23/16:54:05","20%","8");

INSERT INTO history VALUE("14","2022-09-23/16:54:05","70%","10");

INSERT INTO history VALUE("2","2022-09-23/16:54:05","17%","2");

INSERT INTO history VALUE("3","2022-09-23/16:54:05","92%","7");



INSERT INTO history VALUE("15","2022-09-23/16:45:05","12%","2");

INSERT INTO history VALUE("13","2022-09-23/16:45:05","60%","16");

INSERT INTO history VALUE("14","2022-09-23/16:45:05","12%","30");

INSERT INTO history VALUE("2","2022-09-23/16:45:05","99%","25");

INSERT INTO history VALUE("3","2022-09-23/16:45:05","2%","1");

INSERT INTO history VALUE("3","2022-09-23/16:45:05","55%","13");

INSERT INTO history VALUE("3","2022-09-23/16:45:08","24%","17");
INSERT INTO history VALUE("3","2022-09-23/16:45:11","2%","15");
INSERT INTO history VALUE("3","2022-09-23/16:45:14","2%","5");
INSERT INTO server_list VALUE("3","server_1","on");

INSERT INTO server_list VALUE("2","server_2","off");

INSERT INTO server_list VALUE("14","server_3","on");

INSERT INTO server_list VALUE("13","server_4","off");
INSERT INTO server_list VALUE("15","server_5","on");


select * from history;
